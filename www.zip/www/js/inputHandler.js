


function storeTask() {
alert("loaded script");
console.log('storeTask');

var togglelist = document.getElementById("togglelist");
var toggle = togglelist.options[togglelist.selectedIndex].value;


//get inputs of add event screen and save to text file
    eventName = document.getElementById('name').value;
    eventDate = document.getElementById("date").value;
    eventNotes = document.getElementById("notes").value;

    if (toggle === "yes"){

        listItem1 = document.getElementById("item1").value;
        listItem2 = document.getElementById("item2").value;
        listItem3 = document.getElementById("item3").value;
        listItem4 = document.getElementById("item4").value;
        listItem5 = document.getElementById("item5").value;

    }

//store contents in localstorage
/*
    taskcontents = [
        "name",
        "date",
        "notes",
        "item1",
        "item2",
        "item3",
        "item4",
        "item5"
    ];

    taskcontents[0] = eventName;
    taskcontents[1] = eventDate;
    taskcontents[2] = eventNotes;
    if (toggle==="yes"){
        taskcontents[3] = listItem1;
        taskcontents[4] = listItem2;
        taskcontents[5] = listItem3;
        taskcontents[6] = listItem4;
        taskcontents[7] = listItem5;
        }

        //convert array to JSON string
   taskString = JSON.stringify(taskcontents);


    //save JSON string in local storage and increment tasknum by 1
    localStorage.setItem("task"+numberOfTasks, taskString);
   // tasks = [];
    tasks[numberOfTasks] = JSON.parse(taskString);
    numberOfTasks++;
    localStorage.setItem("tasknum",numberOfTasks.toString());




    console.log("completed script, showing result");
    alert(tasks[0]);

    console.log("Redirect to start page");
    window.location.href="index.html";
*/
    _NAME = 'TASKSTORE';

        _tasks = [];

        this.initialize = function(empty) {

            if (empty === true) {
                console.log('init empty');
                localStorage.removeItem(_NAME); // clear data
                _tasks = [];
                localStorage.setItem(_NAME, JSON.stringify(_tasks)); // init empty
            } else {
                _tasks = JSON.parse(localStorage.getItem(_NAME));

                if (_tasks == null) {
                    _tasks = [];
                }

                console.log('init');
                console.log(_tasks);
            }
        };

    this.getTasks = function() {
        return _tasks;
    };

    this.addTasks = function(eventName, eventDate, eventNotes) {
        _tasks.push({Name: eventName, date: eventName, notes:eventNotes});

        console.log('items added');
        console.log(_tasks);
        localStorage.setItem(_NAME, JSON.stringify(_tasks));
    };

    this.removeTasks = function(name) {
        for(var i = _tasks.length - 1; i >= 0; i--) {
            if(_tasks[i].name === name) {
                _tasks.splice(i, 1);
            }
        }
        console.log('items removed');
        console.log(_tasks);
        localStorage.setItem(_NAME, JSON.stringify(_tasks));
    }


}

function showval() {



}



