


function storeTask() {
alert("loaded script");
console.log('storeTask');

//get inputs of add event screen and save to text file
    eventName = document.getElementById('name').value;
//var eventDate = document.getElementById("");
//var eventTime = document.getElementById("");
var eventNotes = document.getElementById("notes");


//create and store files for storing tasks
//var strEventName = eventName.toString();

alert(eventName);

    localStorage.setItem(eventName, eventName);

    alert(localStorage.getItem(eventName));
    console.log("val before refresh"+eventName);
    document.getElementById('test').innerHTML = localStorage.getItem(eventName);



}

function showval() {

        console.log("showval called");
        alert(localStorage.getItem(eventName).toString());







}

