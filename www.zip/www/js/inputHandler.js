


function storeTask() {
alert("loaded script");
console.log('storeTask');

var togglelist = document.getElementById("togglelist");
var toggle = togglelist.options[togglelist.selectedIndex].value;
var numberOfTasks = 0;
localStorage.setItem("tasknum", numberOfTasks.toString());

//get inputs of add event screen and save to text file
    eventName = document.getElementById('name').value;
    eventDate = document.getElementById("date").value;
    eventNotes = document.getElementById("notes").value;

    if (toggle === "yes"){

        listItem1 = document.getElementById("item1").value;
        listItem2 = document.getElementById("item2").value;
        listItem3 = document.getElementById("item3").value;
        listItem4 = document.getElementById("item4").value;
        listItem5 = document.getElementById("item5").value;

    }

//store contents in localstorage

    taskcontents = [
        "name",
        "date",
        "notes",
        "item1",
        "item2",
        "item3",
        "item4",
        "item5"
    ];

    taskcontents[0] = eventName;
    taskcontents[1] = eventDate;
    taskcontents[2] = eventNotes;
    if (toggle==="yes"){
        taskcontents[3] = listItem1;
        taskcontents[4] = listItem2;
        taskcontents[5] = listItem3;
        taskcontents[6] = listItem4;
        taskcontents[7] = listItem5;
        }

        //convert array to JSON string
   taskString = JSON.stringify(taskcontents);


    //save JSON string in local storage and increment tasknum by 1
    localStorage.setItem("task"+numberOfTasks, taskString);
    numberOfTasks++;
    localStorage.setItem("tasknum",numberOfTasks.toString());


    tasks = [];
    tasks[0] = JSON.parse(taskString);

    console.log("completed script, showing result");
    alert(tasks[0]);




}

function showval() {

    alert(localStorage.getItem("task0"));




}

