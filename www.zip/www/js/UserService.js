/*
UserService.js codebase provided by Simon Isler
 */


class UserService {
    // initializing
    constructor (empty) {
        this._NAME = 'USERSERVICE';
        this._items = [];

            // empty array
            if (empty === true) {
                localStorage.removeItem(this._NAME); // clear data
                this._items = [];
                localStorage.setItem(this._NAME, JSON.stringify(this._items)); // init empty
            } else {
                // falls array nicht leer ist
                this._items = JSON.parse(localStorage.getItem(this._NAME));

                if (this._items == null) {
                    this._items = []; // clear data
                }

                console.log(this._items);
            }
        };

    // show content
     getUsers(){
        return this._items;


    };

    // add data
    addUser(name, date, notes, item1, item2, item3, item4, item5) {
        this._items.push({Name: name, date: date, notes: notes, item1: item1, item2: item2, item3: item3, item4: item4, item5: item5});

        console.log(this._items);
        localStorage.setItem(this._NAME, JSON.stringify(this._items));
    }

    removeUser(name) { //Unused function
        for(var i = this._items.length - 1; i >= 0; i--) {
            if(this._items[i].betreff === document.getElementById('betreff').value) {
                this._items.splice(i, 1);
            }
        }

        console.log(this._items);
        localStorage.setItem(this._NAME, JSON.stringify(this._items));
    }
}


function addEvent() {
    //save input
    var togglelist = document.getElementById("togglelist");
    var toggle = togglelist.options[togglelist.selectedIndex].value;


//get inputs of add event screen and save to text file
    eventName = document.getElementById('name').value;
    eventDate = document.getElementById("date").value;
    eventNotes = document.getElementById("notes").value;

    //itemlist remains empty if checkbox was set to "no" or no item was specified after selecting "yes"
    //empty values will not be displayed on all events screen or homepage (WIP)
    listItem1 = document.getElementById("item1").value;
    listItem2 = document.getElementById("item2").value;
    listItem3 = document.getElementById("item3").value;
    listItem4 = document.getElementById("item4").value;
    listItem5 = document.getElementById("item5").value;

    

    // call userservice
    var userService = new UserService();

    // add
    userService.addUser(eventName, eventDate, eventNotes, listItem1, listItem2, listItem3, listItem4, listItem5);

    // show
    alert("Successfully added "+eventName);
    window.location.href="index.html";

}

function showEvents() {
    // call userservice
    var userService = new UserService();


    var data = JSON.stringify(userService.getUsers());
  document.getElementById("testing").textContent=data;




}

// delete certain events
function remove() {
    // call userservice
    var userService = new UserService();

    // E
    //userService.removeUser(document.getElementById('betreff').value);
}

// Wipe local storage
function removeAll() {
    localStorage.clear();
}


